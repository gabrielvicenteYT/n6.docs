# How To Help: Docs

We use MkDocs Material. Here is a good [get started guide](https://squidfunk.github.io/mkdocs-material/getting-started/). Use the instalation instruction, and then clone the repo. 

Please make sure all docs additions are related to their topic, and is correctly categorised under folders. Also, try to tie docs to functions. 
