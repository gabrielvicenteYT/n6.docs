# NASIX.js

Supercharge Your Website. 

# Getting Started: 

Add <script src="https://cdn.jsdelivr.net/npm/nasix.js@latest/core.min.js"></script> to the very bottom of your page.
If you want script to run after loading of NASIX, then add 'let r.initapp = yourinitfunction' .

If you need help, check out our [GitHub Issues](https://github.com/steviebeenz/nasix.js/issues) or [![Gitter](https://badges.gitter.im/nasix-js/community.svg)](https://gitter.im/nasix-js/community?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)